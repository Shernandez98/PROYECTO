package controllers;

    import models.Usuario;
    import org.springframework.web.bind.annotation.GetMapping;
    import org.springframework.web.bind.annotation.RequestMapping;
    import org.springframework.web.bind.annotation.RestController;

    @RestController
    public class UsuarioController {

        @GetMapping(value = "/usuario")
        public Usuario getUsuario(){
            Usuario usuario = new Usuario();
            usuario.setNombre("Selvin");
            usuario.setApellido("Hernandez");
            usuario.setEmail("selvin@gmail.com");
            usuario.setTelefono("55702114");
            usuario.setPassword("55702114");
            return usuario;
    }
        @GetMapping("/buscar")
        public Usuario buscar(){
            Usuario usuario = new Usuario();
            usuario.setNombre("Selvin");
            usuario.setApellido("Hernandez");
            usuario.setEmail("selvin@gmail.com");
            usuario.setTelefono("55702114");
            return usuario;
        }
    }


