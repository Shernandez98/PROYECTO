package PROYECTO.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyecApplicationTests {

	@Test
	void contextLoads() {
	}

}
